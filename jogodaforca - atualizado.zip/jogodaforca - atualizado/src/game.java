

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JEditorPane;
import com.jgoodies.forms.factories.DefaultComponentFactory;

public class game {

	private JFrame frame;
	private JTextField campoTexto;
	private String letra;
	private JogoDaForca jogo;
	private ImageIcon icon;
	private JLabel campoPosicoes;
	private JLabel campoPalavra;
	private JLabel acertos;
	private JLabel erros;
	String[] penalidades = {"perna1", "perna2", "bra�o1", "bra�o2", "tronco", "cabe�a"};
	private String[] corpo = {"1.png", "2.png","3.png","4.png","5.png","6.png"};
	ArrayList<Integer> posicoes;
	String[] letrasAdivinhadas;
	private JLabel campoAtencao;
	private JLabel labelAlerta;
	private JLabel forca;
	private JLabel imgFundo;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					game window = new game();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public game() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel digiteLetra = new JLabel("DIGITE UMA LETRA");
		digiteLetra.setBounds(156, 116, 124, 23);
		frame.getContentPane().add(digiteLetra);
		
		campoTexto = new JTextField();
		campoTexto.setBounds(156, 137, 97, 23);
		frame.getContentPane().add(campoTexto);
		campoTexto.setColumns(10);
		
		JLabel dica = new JLabel("DICA:");
		dica.setBounds(135, 11, 46, 14);
		frame.getContentPane().add(dica);
		
		JLabel campoDica = new JLabel("...");
		campoDica.setBounds(171, 7, 152, 23);
		frame.getContentPane().add(campoDica);
		
		JButton botao_ok = new JButton("OK");
		botao_ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				letra = campoTexto.getText().toUpperCase();
				campoTexto.setText("");
				campoAtencao.setText("...");
				frame.getRootPane().setDefaultButton(botao_ok);
			  
					try {
						posicoes = jogo.getPosicoes(letra);					
						if (posicoes.size()>0) {
							//lblNewLabel_3.setText("posicoes encontradas=");
							System.out.println("Posições encontradas="+ posicoes);
							campoPosicoes.setText("Posições encontradas="+posicoes);				
							for(int i : posicoes)
								letrasAdivinhadas[i] = letra;
							System.out.println(Arrays.toString(letrasAdivinhadas));
							campoPalavra.setText(Arrays.toString(letrasAdivinhadas));
							System.out.println("Acertos="+jogo.getAcertos());
							acertos.setText("Acertos = "+jogo.getAcertos());
						}else {
							System.out.println("Você errou! - Penalidade= "+jogo.getPenalidade()+", retirar "+ penalidades[jogo.getPenalidade()-1]);
							//if(jogo.getPenalidade() == 1) {
								
								int x = jogo.getPenalidade();
								for(int i = 1; i<corpo.length +1; i++){
									if(i == x){
										icon = new ImageIcon(game.class.getResource("/imagens/" + corpo[jogo.getPenalidade()-1]));
										forca.setIcon(icon); 
										icon.setImage(icon.getImage().getScaledInstance(forca.getWidth(), forca.getHeight(), 1) );
										forca.setIcon(icon);
									}
								//}						
												
							}
							
							erros.setText("Erros = " + jogo.getPenalidade());
							forca.setText(penalidades[jogo.getPenalidade()-1]);
						}
					}
					catch(Exception a) {
						System.out.println(a.getMessage());
						campoAtencao.setText(a.getMessage());
						
					}
					/*catch(NullPointerException b) {
						System.out.println(b.getMessage());
						lblNewLabel_7.setText("clique em iniciar o jogo");					
					}*/
									
				if(jogo.terminou() == true) {
					String mensagem = "\n           ---- game over ----" + 
				                      "\nResultado Final = " + jogo.getResultado() + 
				                      "\nSituação Final = " + Arrays.toString(letrasAdivinhadas);
					JOptionPane.showMessageDialog(null, mensagem);
				};
			}
		});
		botao_ok.setBounds(263, 137, 52, 23);
		frame.getContentPane().add(botao_ok);
		botao_ok.setEnabled(false);
		
		JButton botaoJogar = new JButton("Jogar");
		botaoJogar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					jogo = new JogoDaForca("palavras.txt");
					icon = new ImageIcon(game.class.getResource("/imagens/0.png"));
					forca.setIcon(icon);
					
					icon.setImage(icon.getImage().getScaledInstance(forca.getWidth(), forca.getHeight(), 1) );
					forca.setIcon(icon);
					
					
					jogo.iniciar();									
					campoDica.setText(jogo.getDica());
					letrasAdivinhadas = new String[jogo.getTamanho()];	
					Arrays.fill(letrasAdivinhadas, "");
					botao_ok.setEnabled(true);
					
					//em caso de inicio de uma nova partida
					campoPosicoes.setText("*");
					campoPalavra.setText("- - - - - -");
					acertos.setText("Acertos = 0");
					erros.setText("Erros = 0");
					campoAtencao.setText("...");
					
					
					
					
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		botaoJogar.setBounds(156, 189, 124, 23);
		frame.getContentPane().add(botaoJogar);
		
		campoPosicoes = new JLabel("*");
		campoPosicoes.setBounds(241, 223, 183, 31);
		frame.getContentPane().add(campoPosicoes);
		
		campoPalavra = new JLabel("- - - - - -");
		campoPalavra.setFont(new Font("Tahoma", Font.BOLD, 19));
		campoPalavra.setBounds(171, 74, 158, 31);
		frame.getContentPane().add(campoPalavra);
		
		acertos = new JLabel("Acertos = 0");
		acertos.setForeground(Color.GREEN);
		acertos.setBounds(354, 11, 70, 14);
		frame.getContentPane().add(acertos);
		
		erros = new JLabel("Erros = 0");
		erros.setForeground(Color.RED);
		erros.setBounds(354, 28, 52, 14);
		frame.getContentPane().add(erros);
		
		campoAtencao = new JLabel("...");
		campoAtencao.setBounds(70, 223, 259, 31);
		frame.getContentPane().add(campoAtencao);
		
		labelAlerta = new JLabel("ALERTA:");
		labelAlerta.setForeground(Color.BLUE);
		labelAlerta.setBounds(20, 227, 86, 23);
		frame.getContentPane().add(labelAlerta);
		
		forca = new JLabel("FORCA");
		forca.setBounds(20, 43, 97, 117);
		frame.getContentPane().add(forca);
		
		imgFundo = new JLabel("Fundo");
		imgFundo.setBounds(0, -3, 434, 264);
		frame.getContentPane().add(imgFundo);
		ImageIcon icon =new ImageIcon(Janela.class.getResource("/imagens/fundo.jpg" ));
		icon.setImage(icon.getImage().getScaledInstance(imgFundo.getWidth(), imgFundo.getHeight(), 1) );
		imgFundo.setIcon(icon);
		
	}
}
